import socket

CRLF="\r\n"
target_host = "hw2.csec380.fun"
target_port = 380
target_header = "CSEC-380"

URL = "?username=alice&password=SecretPassword123!" + CRLF
firstline = "POST /captchaLogin" + "HTTP/1.1" + CRLF
secondline = "User-Agent: " + target_header + CRLF
thirdline = "POST /captchaValidate HTTP/1.1" + CRLF
fourthline = "POST /captchaSecurePage HTTP/1.1" + CRLF



def calibrate():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((target_host, target_port))
    request = firstline + secondline + CRLF
    client.send(request.encode())
    httpresponse = client.recv(8192)
    response = httpresponse.decode()
    httpresponse = client.recv(8192)
    response = response + httpresponse.decode()
    print(response)
    client.close()

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((target_host, target_port))
    request = thirdline + secondline + CRLF
    client.send(request.encode())
    httpresponse = client.recv(8192)
    client.send(request.encode())
    response = httpresponse.decode()
    httpresponse = client.recv(8192)
    response = response + httpresponse.decode()
    print(response)
    client.close()

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((target_host, target_port))
    request = fourthline + secondline + CRLF
    client.send(request.encode())
    httpresponse = client.recv(8192)
    client.send(request.encode())
    response = httpresponse.decode()
    httpresponse = client.recv(8192)
    response = response + httpresponse.decode()
    print(response)
    client.close()

calibrate()